package daemon

import "testing"

func TestDaemon(t *testing.T) {
	// TODO
}
