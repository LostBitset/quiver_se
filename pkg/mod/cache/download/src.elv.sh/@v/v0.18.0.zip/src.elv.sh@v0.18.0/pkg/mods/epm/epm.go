package epm

import _ "embed"

// Code contains the source code of the epm module.
//go:embed epm.elv
var Code string
