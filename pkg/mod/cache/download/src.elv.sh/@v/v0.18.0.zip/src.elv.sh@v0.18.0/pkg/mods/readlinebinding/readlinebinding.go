package readlinebinding

import _ "embed"

// Code contains the source code of the readline-binding module.
//go:embed readline-binding.elv
var Code string
