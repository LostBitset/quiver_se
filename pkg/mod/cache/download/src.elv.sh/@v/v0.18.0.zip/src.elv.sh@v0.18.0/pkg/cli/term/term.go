// Package term provides functionality for working with terminals.
package term

import "src.elv.sh/pkg/logutil"

var logger = logutil.GetLogger("[cli/term] ")
