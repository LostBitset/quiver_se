// Package fsutil provides filesystem utilities.
package fsutil
