// Package diag contains building blocks for formatting and processing
// diagnostic information.
package diag
