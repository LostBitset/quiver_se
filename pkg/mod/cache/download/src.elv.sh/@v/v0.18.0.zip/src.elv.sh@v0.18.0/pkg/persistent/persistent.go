// Package persistent contains subpackages for persistent data structures,
// similar to those of Clojure.
package persistent
