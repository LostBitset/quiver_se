// Package store defines the permanent storage service.
package store
