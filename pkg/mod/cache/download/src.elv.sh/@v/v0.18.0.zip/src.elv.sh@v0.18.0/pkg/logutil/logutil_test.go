package logutil

import "testing"

func TestLogger(t *testing.T) {
	// TODO
}
