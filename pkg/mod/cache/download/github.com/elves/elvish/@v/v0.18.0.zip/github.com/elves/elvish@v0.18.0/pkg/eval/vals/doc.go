// Package vals contains basic facilities for manipulating values used in the
// Elvish runtime.
package vals
