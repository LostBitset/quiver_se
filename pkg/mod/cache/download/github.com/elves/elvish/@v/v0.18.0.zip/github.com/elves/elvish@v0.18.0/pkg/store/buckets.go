package store

const (
	bucketCmd       = "cmd"
	bucketDir       = "dir"
	bucketSharedVar = "shared_var"
)

// The following buckets were used before and are thus reserved:
// "schema"
