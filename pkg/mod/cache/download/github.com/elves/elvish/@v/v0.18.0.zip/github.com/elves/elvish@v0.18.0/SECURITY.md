# Security Policy

## Supported Versions

Only the HEAD and the last release is supported by the developers of Elvish.

However, since some operating systems contain outdated Elvish packages, please
also feel free to get in touch for security issues in unsupported versions. You
can check the versions of Elvish packages on
[Repology](https://repology.org/project/elvish/versions).

## Reporting a Vulnerability

Please contact Qi Xiao at xiaqqaix@gmail.com.
