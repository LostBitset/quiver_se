// Package histutil provides utilities for working with command history.
package histutil
