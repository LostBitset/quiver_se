package parseutil

import "testing"

func Test(t *testing.T) {
	// Required to get accurate test coverage report.
}
