package eval_test

import (
	"testing"

	. "src.elv.sh/pkg/eval/evaltest"
)

func TestBuiltinFnCmd(t *testing.T) {
	Test(t /* TODO: Add test cases */)
}
